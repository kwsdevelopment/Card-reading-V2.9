"""Draws the launcher icons (run once; the PNGs are already in icons/)."""
from PIL import Image, ImageDraw
import os
def glyph(d, s, ox=0, oy=0, k=1.0):
    # two stacked cards seen from the side, with pen dots
    def R(x0,y0,x1,y1,r,fill,out=None,w=0):
        d.rounded_rectangle([ox+x0*s*k+ (1-k)*s/2, oy+y0*s*k+(1-k)*s/2, ox+x1*s*k+(1-k)*s/2, oy+y1*s*k+(1-k)*s/2], r*s*k, fill=fill, outline=out, width=w)
    R(.22,.30,.80,.70,.06,(234,240,255,255))
    for i,(x,y) in enumerate([(.30,.36),(.40,.45),(.50,.54),(.60,.63)]):
        R(x-.03,y-.025,x+.03,y+.025,.02,(7,11,22,255))
    R(.22,.62,.80,.70,.04,(34,211,238,255))
def make(size, round_=False, fg_only=False):
    im=Image.new('RGBA',(size,size),(0,0,0,0)); d=ImageDraw.Draw(im)
    if not fg_only:
        bg=Image.new('RGBA',(size,size)); bd=ImageDraw.Draw(bg)
        for y in range(size):
            t=y/size; bd.line([(0,y),(size,y)],fill=(int(34+(99-34)*t),int(211+(102-211)*t),int(238+(241-238)*t),255))
        m=Image.new('L',(size,size),0); ImageDraw.Draw(m).rounded_rectangle([0,0,size-1,size-1],size//2 if round_ else size*0.22,fill=255)
        im.paste(bg,(0,0),m); d=ImageDraw.Draw(im)
    glyph(d,size,k=0.62 if fg_only else 1.0)
    return im
os.makedirs('icons',exist_ok=True)
for name,leg,fg in [('mdpi',48,108),('hdpi',72,162),('xhdpi',96,216),('xxhdpi',144,324),('xxxhdpi',192,432)]:
    make(leg).save(f'icons/{name}_ic_launcher.png'); make(leg,True).save(f'icons/{name}_ic_launcher_round.png'); make(fg,fg_only=True).save(f'icons/{name}_ic_launcher_foreground.png')
make(512).save('icons/icon-512.png')
