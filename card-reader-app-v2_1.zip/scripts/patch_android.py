"""Runs in GitHub Actions right after `npx cap add android`: camera permission, icons, colours."""
import os, re, shutil
root = 'android/app/src/main'
mf = os.path.join(root, 'AndroidManifest.xml'); s = open(mf, encoding='utf-8').read()
add = ('    <uses-permission android:name="android.permission.CAMERA" />\n'
       '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'
       '    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />\n')
if 'android.permission.CAMERA' not in s:
    s = s.replace('<application', add + '    <application', 1)
open(mf, 'w', encoding='utf-8').write(s)
res = os.path.join(root, 'res')
for d in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
    for n in ['ic_launcher', 'ic_launcher_round', 'ic_launcher_foreground']:
        dst = os.path.join(res, 'mipmap-' + d, n + '.png'); os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(f'icons/{d}_{n}.png', dst)
bg = os.path.join(res, 'values', 'ic_launcher_background.xml')
os.makedirs(os.path.dirname(bg), exist_ok=True)
open(bg, 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B1426</color>\n</resources>\n')
print('android project patched')
