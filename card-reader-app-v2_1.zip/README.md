# Card Reader (Android app)

Phone camera se card stack ke side par bane pen-dots padhta hai.
Har **5 mm = 1 number** (0-5 mm = 1, 5-10 mm = 2, ... 60-65 mm = 13), card length 89 mm.

**Login:** username `Admin`, password `AdminTS12383@@`

## APK banane ke steps (GitHub par, computer pe kuch install nahi karna)

1. GitHub par naya repository banao (jaise `card-reader`).
2. Is zip ke andar ki **saari files aur folders** (`.github`, `www`, `icons`, `scripts`, `package.json`, `capacitor.config.json`, ...) repository mein upload karo.
   Dhyan do: `.github` folder bhi jana chahiye, wahi APK banata hai. Agar upload mein ye folder na jaye, to GitHub par **Add file > Create new file** mein naam `.github/workflows/build-apk.yml` likho aur us file ka text paste karo.
3. Repository ke **Actions** tab par jao. Build apne aap shuru ho jayega (ya **Build Android APK** > **Run workflow** dabao). 5-8 minute lagte hain.
4. Build ke baad us run ko kholo. Neeche **Artifacts** mein **CardReader-APK** milega. Use download karo, zip kholo, `app-debug.apk` nikalo.
5. APK ko phone mein daalo aur install karo (agar phone puche to "Install unknown apps" allow karo).
6. App kholo, login karo, camera permission **Allow** karo.

## App kaise chalaye

* **START** dabao: camera chalu, app live padhta rehta hai.
* **+ / -** (right side) se zoom karo, **< ^ v >** se frame left/right/up/down khiskao. Card ko poora frame mein bharo.
* Jab 3 baar ek jaisa result aata hai to camera **apne aap band** ho jata hai (Settings mein band kar sakte ho). Ya khud **STOP** dabao.
* Result sahi na lage to dubara **START**.
* Result niche: total cards, odd side, even side, number-wise count, poori list, aur ek number search.
* **Read a photo**: gallery ki photo bhi padh sakte ho.
* Card ke kinare galat pakde gaye hon to "Detected dots" ke neeche blue lines slider se theek karke **Re-read** dabao.

## Naya: zyada accurate reading
* **Camera mode** (Settings): **Live + auto** (camera padhta rehta hai) ya **Capture only** (sirf preview, jab ready ho tab CAPTURE dabao).
* **CAPTURE / camera button**: dabate hi screen ke frame ka turant result dikha deta hai, aur saath mein ek sharp HD photo khinch kar usse dobara padhta hai; HD result aate hi number apne aap update ho jate hain. Result ke baad camera band ho jata hai aur START AGAIN / RESTART aata hai.
* **HD photo check** (Settings, default ON): Live mode mein jab reading stable ho jaati hai, app khud ek HD photo kheench kar dobara padhta hai aur wahi final result dikhata hai. Photo na mile to camera frame / live result use hota hai.
* **Blur skip**: jab camera focus kar raha hota hai aur frame dhundhla hota hai, app us frame ko ignore karta hai.
* **Tap-to-focus**: card ke kinare par ek baar tap karo, wahan focus hoga (peela circle). Zoom / move karne ke baad app khud box ke beech par focus karta hai. (Kuch phones focus point support nahi karte; tab normal continuous focus chalta hai.)

## Speed (reader 3.5x tez)
* Reader ab sirf zaroori hissa compute karta hai (card ke aas-paas ki columns), kamzor dusre bands skip karta hai aur blur ke loops tez hain. Aapki 2 asli photos par purane aur naye reader ka result **number-by-number bilkul same** nikla; time ~1000 ms se ~280 ms (laptop par).
* Photo ke baad screen par "(x.x s)" dikhta hai.

## TAKE PHOTO (sabse accurate)
* **TAKE PHOTO** button phone ka **apna camera app** kholta hai (focus + HD wahi jo aap bahar use karte ho). Photo lene ke baad wo seedha usi reader se padha jata hai jisse gallery photo padhi jati hai. Purana result photo aate hi hat jata hai.
* Picture wala button = gallery se photo padhna. **LIVE CAMERA** optional hai (beta).
* Photo padhna ~3 guna tez (quick slope search) aur screen par kitne second lage wo dikhta hai.
* Agar TAKE PHOTO camera ki jagah gallery khole to batao, Capacitor Camera plugin jod diya jayega.

## Auto best shot (live camera)
* **Settings > Camera mode > Auto best shot**: live preview mein bhaari reading nahi hoti. App sirf dekhta hai ki card ki edge patti mein hai, phone **steady** hai aur picture **sharp** hai. Jaise hi ye teeno mil jate hain, wo **khud HD photo khinch kar padhta hai**, camera band karta hai aur result dikhata hai. Aage-peeche / upar-neeche karte raho, best shot par apne aap capture ho jayega.
* Photo mein card na mile to app chup-chap phir dhundhta rehta hai (view badalne par ya 8 second baad dobara try).
* **Auto-capture best shot** switch (Settings) band karo to sirf manual camera button se photo hogi.
* **Sirf card ki edge ke dots**: edge ke upar (card ka top face) ya neeche ke dots ignore hote hain. Agar asli card ke dots kat rahe hon to **Strict card check** OFF karo.

## Controls (bars)
* **Right bar**: thumb upar = zoom in, neeche = zoom out. **Left bar**: frame upar / neeche. **Bottom bar**: frame left / right. Purane +/- aur arrow buttons hata diye.
* **Capture button**: photo khinchte hi result aata hai, camera dobara chalu **nahi** hota. Hamesha photo screen par rehti hai aur neeche **START AGAIN / RESTART** aata hai (card na mile tab bhi, "Card not detected" ya "Zoom out" ke saath).
* Capture mein 3 readings (2 camera frames + HD photo) ko milakar sahi number chuna jata hai (2 ka agree hona).
* Card ke dono kinare box ke andar hone chahiye; kinara kat raha ho to "Zoom out" aata hai (warna mm ka scale galat ho jata hai).
* Focus: phone support kare to app khud focus distance ghuma kar card ki edge ka sabse sharp point lock karta hai.

## Reading strip (patti)
* Camera chalu hote hi box ke beech ek **fixed patti** dikhti hai (black & white, cyan border). **Sirf us patti ke andar** padha jata hai, baaki sab blur hai aur ignore hota hai.
* Patti ki height Settings mein **Reading strip height** se set hoti hai (default 30%: 52 cards + thodi jagah). Card ki edge ko patti ke andar rakho.
* Result **3 lagataar milti-julti readings** par turant lock ho jata hai aur camera band; ek card ka chhota farak ho to majority se theek ho jata hai. Uske baad camera hilane se result nahi badalta.

## Sirf card ki edge (strict card check)
* **Strict card check** (Settings, default ON): app sirf asli dotted card-edge ko padhta hai. Almari / background jaisi cheezein "Card not detected" ban jati hain. Agar asli card par bhi ye message aaye to is switch ko OFF karo.
* Card mil jaye to uske bahar ka hissa **blur + dim** ho jata hai aur ek cyan box dikhta hai: dots sirf usi box ke andar ginti hote hain.
* **Auto focus**: camera khud card ki edge par focus karta hai (card hile to focus bhi saath jata hai).
* **Fast**: card ki jagah yaad rakhkar live reading ~5 guna tez hoti hai.
* **Naya start = saaf slate**: START / START AGAIN / RESTART / photo padhne par purana result turant hat jata hai.

## Tips for best result
* Camera ek **wide patti (strip)** mein dikhta hai: card ki poori width aati hai, height kam, taaki screen ka zyada hissa na ghere. Ye upar fixed rehta hai, neeche result scroll hota hai.
* **Do ungli se pinch** karo to zoom hota hai (sirf us box ke andar), **ek ungli se drag** karo to frame khiskta hai, **double tap** se reset. + / - aur teer wale buttons bhi hain.
* Settings (gear) mein **Screen: Auto / Portrait / Landscape**. Upar ka rotate button bhi Auto > Landscape > Portrait badalta hai. Jo accha lage use lock kar do, app yaad rakhta hai.
* Camera ko phone ki sabse badi HD quality (4K tak) mein kholta hai, continuous focus ke saath. Upar pill mein resolution dikhta hai.
* Live dikhne wale circle wo dots hain jo app ne padhe, neeli lines card ke kinare. Card ke dono kinare box ke andar rakho.
* Phone ko sidha rakho, card stack ka side kinara camera ke saamne, achhi roshni. Card ke left kinare ko barabar (aligned) rakho.

## Note
Login fixed hai aur app ke andar rakha hai (password plain text nahi, hash ke roop mein). Ye casual lock hai; koi APK kholkar bypass kar sakta hai. Asli security ke liye server chahiye.
