"use strict";
/* ============================================================
   Card Reader - login, live camera (zoom / pan / start-stop) and result screen.
   The reading itself runs in worker.js -> engine.js (band mode: every 5 mm = one number).
   ============================================================ */
const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};

/* ---------------- login (fixed account) ---------------- */
// Only a salted SHA-256 of "cr1|username|password" is kept here, not the password itself.
const LOGIN_HASH = "2d955cbd85dd71315d0740f9f410edd24fd2e6eb403c1d5e4afdf03db20a629a";
function sha256js(str) {            // small fallback for webviews without crypto.subtle
  const m = new TextEncoder().encode(str), l = m.length, K = [], H = [];
  const rr = (x, n) => (x >>> n) | (x << (32 - n));
  let pc = 0; for (let c = 2; pc < 64; c++) { let ok = true; for (let i = 2; i * i <= c; i++) if (c % i === 0) { ok = false; break; }
    if (ok) { K[pc] = (Math.pow(c, 1 / 3) * 4294967296) | 0; if (pc < 8) H[pc] = (Math.pow(c, .5) * 4294967296) | 0; pc++; } }
  const n = (((l + 8) >> 6) + 1) << 4, w = new Array(n * 1).fill(0);
  for (let i = 0; i < l; i++) w[i >> 2] |= m[i] << (24 - 8 * (i & 3));
  w[l >> 2] |= 0x80 << (24 - 8 * (l & 3)); w[n - 1] = l * 8;
  for (let j = 0; j < n; j += 16) {
    const v = w.slice(j, j + 16), a = H.slice();
    for (let i = 16; i < 64; i++) { const s0 = rr(v[i - 15], 7) ^ rr(v[i - 15], 18) ^ (v[i - 15] >>> 3), s1 = rr(v[i - 2], 17) ^ rr(v[i - 2], 19) ^ (v[i - 2] >>> 10); v[i] = (v[i - 16] + s0 + v[i - 7] + s1) | 0; }
    let [A, B, C, D, E, F, G, Hh] = a;
    for (let i = 0; i < 64; i++) {
      const t1 = (Hh + (rr(E, 6) ^ rr(E, 11) ^ rr(E, 25)) + ((E & F) ^ (~E & G)) + K[i] + v[i]) | 0, t2 = ((rr(A, 2) ^ rr(A, 13) ^ rr(A, 22)) + ((A & B) ^ (A & C) ^ (B & C))) | 0;
      Hh = G; G = F; F = E; E = (D + t1) | 0; D = C; C = B; B = A; A = (t1 + t2) | 0;
    }
    [A, B, C, D, E, F, G, Hh].forEach((x, i) => H[i] = (H[i] + x) | 0);
  }
  return H.map(x => (x >>> 0).toString(16).padStart(8, "0")).join("");
}
async function sha256(s) {
  try { if (crypto && crypto.subtle) { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join(""); } } catch (e) {}
  return sha256js(s);
}
function showApp(on) { $("login").classList.toggle("hide", on); $("app").classList.toggle("hide", !on); if (on) window.scrollTo(0, 0); }
$("lform").addEventListener("submit", async e => {
  e.preventDefault();
  const h = await sha256("cr1|" + $("lu").value.trim().toLowerCase() + "|" + $("lp").value);
  if (h === LOGIN_HASH) { store.set("cr_ok", "1"); $("lerr").textContent = ""; $("lp").value = ""; showApp(true); }
  else { $("lerr").textContent = "Wrong username or password."; const c = $("lform"); c.classList.remove("shake"); void c.offsetWidth; c.classList.add("shake"); }
});
$("leye").addEventListener("click", () => {
  const p = $("lp"), show = p.type === "password"; p.type = show ? "text" : "password";
  $("leye").innerHTML = `<svg class="i"><use href="#i-${show ? "eyeoff" : "eye"}"/></svg>`;
});
$("logout").addEventListener("click", () => { stopCam(false); store.del("cr_ok"); showApp(false); });
if (store.get("cr_ok") === "1") showApp(true);

/* ---------------- worker ---------------- */
const workers = [];                                              // 0 = live loop, 1 = quick read on capture, 2 = HD photo read
let seq = 0; const pend = new Map();
function spawn(i) {
  const w = new Worker("worker.js"); workers[i] = w;
  w.onmessage = e => {
    const p = pend.get(e.data.id); if (!p) return; pend.delete(e.data.id);
    e.data.error ? p.reject(new Error(e.data.error)) : p.resolve(e.data.res);
  };
  w.onerror = ev => { const err = new Error("Reader failed to start: " + (ev.message || "")); pend.forEach((p, id) => { if (p.wi === i) { pend.delete(id); p.reject(err); } }); };
}
[0, 1, 2].forEach(spawn);
function killWorker(i) {                                         // stop whatever it is computing and give a fresh, idle worker
  const err = new Error("aborted"); pend.forEach((p, id) => { if (p.wi === i) { pend.delete(id); p.reject(err); } });
  try { workers[i].terminate(); } catch (e) {} spawn(i);
}
function readAsync(canvas, manual, wi, limit) {
  wi = wi || 0;
  return new Promise((resolve, reject) => {
    const im = canvas.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, canvas.width, canvas.height);
    const id = ++seq, timer = setTimeout(() => { pend.delete(id); reject(new Error("Reading took too long.")); }, limit || 25000);
    pend.set(id, { wi, resolve: v => { clearTimeout(timer); resolve(v); }, reject: e => { clearTimeout(timer); reject(e); } });
    workers[wi].postMessage({ id, buf: im.data.buffer, W: canvas.width, H: canvas.height, length: parseFloat($("len").value) || 89, band: parseFloat($("band").value) || 5, manual: manual || {} }, [im.data.buffer]);
  });
}

/* ---------------- settings ---------------- */
$("len").value = store.get("cr_len") || "89"; $("band").value = store.get("cr_band") || "5";
if (store.get("cr_auto") === "0") $("autostop").classList.remove("on");
$("len").addEventListener("change", () => store.set("cr_len", $("len").value));
$("band").addEventListener("change", () => store.set("cr_band", $("band").value));
$("autostop").addEventListener("click", () => { const t = $("autostop"); t.classList.toggle("on"); store.set("cr_auto", t.classList.contains("on") ? "1" : "0"); });
let cfgMode = store.get("cr_mode") === "shot" ? "shot" : "live";
function applyMode(m) { cfgMode = m; store.set("cr_mode", m); document.querySelectorAll("#mode button").forEach(b => b.classList.toggle("on", b.dataset.m === m)); }
$("mode").addEventListener("click", e => { const b = e.target.closest("button"); if (b) applyMode(b.dataset.m); });
applyMode(cfgMode);
if (store.get("cr_strict") === "0") $("strict").classList.remove("on");
$("strict").addEventListener("click", () => { const t = $("strict"); t.classList.toggle("on"); store.set("cr_strict", t.classList.contains("on") ? "1" : "0"); });
function camOpts(extra) { const o = Object.assign({}, extra || {}); if ($("strict").classList.contains("on")) o.strict = true; return o; }
if (store.get("cr_hd") === "0") $("hdshot").classList.remove("on");
$("hdshot").addEventListener("click", () => { const t = $("hdshot"); t.classList.toggle("on"); store.set("cr_hd", t.classList.contains("on") ? "1" : "0"); });
$("gear").addEventListener("click", () => $("opts").classList.toggle("hide"));

/* ---------------- screen orientation ---------------- */
let orient = store.get("cr_orient") || "auto";
function applyOrient(m) {
  orient = m; store.set("cr_orient", m);
  document.querySelectorAll("#orient button").forEach(b => b.classList.toggle("on", b.dataset.o === m));
  const SO = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.ScreenOrientation;
  try {
    if (SO) { m === "auto" ? SO.unlock() : SO.lock({ orientation: m }); }
    else if (screen.orientation) { m === "auto" ? screen.orientation.unlock() : screen.orientation.lock(m).catch(() => {}); }
  } catch (e) {}
}
$("orient").addEventListener("click", e => { const b = e.target.closest("button"); if (b) applyOrient(b.dataset.o); });
$("rot").addEventListener("click", () => applyOrient(orient === "auto" ? "landscape" : orient === "landscape" ? "portrait" : "auto"));
window.addEventListener("resize", () => { resetHist(); });
applyOrient(orient);

/* ---------------- state / ui helpers ---------------- */
const READ_W = 2212;                                 // every reading is made at this width (the engine is tuned for it)
const S = { mode: "idle", z: 1, cx: .5, cy: .5, hist: [], last: null, cur: 0, aspect: 12 / 5, sharpBest: 0, blurSkips: 0, miss: 0, capId: 0, loopId: 0, stripH: 0.30, lastTry: 0, failSig: null, noticeUntil: 0, capAuto: false, sweeping: false, sweepT: 0, manualFocus: false, snap: null, hint: null, reads: 0, afPt: null, afT: 0, sig: null, runMode: "live", loopRun: null, wantCapture: false };
const CUTOFF = "Card ends are cut off. Zoom out until both card ends are inside the box.";
function notDetected(e) { const cut = !!(e && /cut off/i.test(e.message || e)); tag(cut ? "Zoom out" : "Card not detected"); hint(cut ? CUTOFF : NOCARD, true); }
const NOCARD = "Card not detected. Point the camera at the card edge and keep both card ends inside the box.";
function hideResult() { S.sig = null; S.last = null; try { octx.clearRect(0, 0, ovc.width, ovc.height); } catch (e) {} $("resBox").classList.add("hide"); $("emptyP").classList.remove("hide"); }
function resetHist() { S.hist = []; S.sharpBest = 0; S.blurSkips = 0; S.hint = null; }
S.stripH = Math.min(.55, Math.max(.18, (+store.get("cr_strip") || 30) / 100));
$("sth").value = Math.round(S.stripH * 100); $("sthv").textContent = Math.round(S.stripH * 100) + "%";
$("sth").addEventListener("input", () => { S.stripH = +$("sth").value / 100; store.set("cr_strip", $("sth").value); $("sthv").textContent = $("sth").value + "%"; resetHist(); updateMask(); });
const canv = [document.createElement("canvas"), document.createElement("canvas")];
const vid = document.createElement("video"); vid.playsInline = true; vid.muted = true; vid.setAttribute("playsinline", "");
let stream = null, wake = null;
const vcv = $("vcv"), vctx = vcv.getContext("2d");

function hint(t, err) { const h = $("hint"); h.textContent = t || ""; h.classList.toggle("err", !!err); }
function pill(txt, cls) { $("pilltxt").textContent = txt; $("pill").className = "pill " + (cls || ""); }
function tag(t, good) { const g = $("vtag"); g.textContent = t || ""; g.classList.toggle("hide", !t); g.classList.toggle("good", !!good); }
function setGo() { syncBtns(); }
function clearResult() {
  S.last = null; resetHist(); $("resBox").classList.add("hide"); $("emptyP").classList.remove("hide");
  try { vctx.clearRect(0, 0, vcv.width, vcv.height); } catch (e) {}
  $("idle").classList.remove("hide"); pill("READY"); tag(""); hint("Ready. Press TAKE PHOTO."); syncBtns();
}
function syncBtns() {
  const cap = S.mode === "capturing", live = S.mode === "live" || cap, shot = S.runMode === "shot";
  $("go").classList.toggle("stop", live && !cap && !shot); $("go").classList.toggle("busy", cap);
  $("gotxt").textContent = cap ? "READING..." : !live ? (S.last ? "LIVE AGAIN" : "LIVE CAMERA") : shot ? "CAPTURE" : "STOP";
  $("takephoto").classList.toggle("hide", live); $("tptxt").textContent = S.last ? "TAKE NEW PHOTO" : "TAKE PHOTO";
  $("go").querySelector("use").setAttribute("href", cap || (live && shot) ? "#i-camera" : !live ? "#i-play" : "#i-stop");
  $("rst").classList.toggle("hide", live || !S.last);
  $("shutter").classList.toggle("hide", !(live && !cap && !shot));
  $("stopbtn").classList.toggle("hide", !(live && !cap && shot));
}
function liveUI(on) {
  ["barZ", "barY", "barX", "zlabel"].forEach(id => $(id).classList.toggle("hide", !on));
  $("idle").classList.toggle("hide", on || !!S.last);
}

/* ---------------- crop (zoom / pan) ---------------- */
function cropRect() {
  const vw = vid.videoWidth, vh = vid.videoHeight, A = S.aspect;
  let bw = vw, bh = vw / A; if (bh > vh) { bh = vh; bw = vh * A; }
  const cw = bw / S.z, ch = bh / S.z;
  const sx = Math.min(Math.max(S.cx * vw - cw / 2, 0), vw - cw), sy = Math.min(Math.max(S.cy * vh - ch / 2, 0), vh - ch);
  S.cx = (sx + cw / 2) / vw; S.cy = (sy + ch / 2) / vh;
  return { sx, sy, cw, ch };
}
/* the reading strip: a fixed bright band in the middle of the box. ONLY this band is read, everything outside is blurred and ignored. */
function stripFrac() { const h = Math.min(.7, Math.max(.15, S.stripH)); return { y0: .5 - h / 2, y1: .5 + h / 2, h }; }
function stripRect() { const r = cropRect(), f = stripFrac(); return { sx: r.sx, sy: r.sy + r.ch * f.y0, cw: r.cw, ch: r.ch * f.h }; }
function stripTopPx() { return stripFrac().y0 * READ_W / S.aspect; }              // strip top, measured on the READ_W-wide full box
function paintStrip(ctx, w, h) { const r = stripRect(); ctx.drawImage(vid, r.sx, r.sy, r.cw, r.ch, 0, 0, w, h); }
function paint(ctx, w, h) { const r = cropRect(); ctx.drawImage(vid, r.sx, r.sy, r.cw, r.ch, 0, 0, w, h); }
const ovc = $("ovc"), octx = ovc.getContext("2d");
function drawLoop() {
  if (S.mode !== "live") return;
  if (vid.videoWidth) {
    const w = 1280, h = Math.round(w / S.aspect);
    if (vcv.width !== w || vcv.height !== h) { vcv.width = w; vcv.height = h; }
    if (ovc.width !== w || ovc.height !== h) { ovc.width = w; ovc.height = h; }
    paint(vctx, w, h); octx.clearRect(0, 0, w, h);
    const L = S.last; if (L && L.key === cropKey() && L.res.rows.length) { const sc = w / L.canvas.width, top = L.top || 0; markers(octx, L.res, sc, -top, top * sc, (top + L.canvas.height) * sc); }
  }
  updateMask(); barUpdaters.forEach(f => f()); requestAnimationFrame(drawLoop);
}
function cropKey() { return S.z.toFixed(3) + "|" + S.cx.toFixed(3) + "|" + S.cy.toFixed(3) + "|" + S.stripH; }
function zlabel() { $("zlabel").textContent = S.z.toFixed(1) + "×"; }
function zoom(f) { S.z = Math.min(10, Math.max(1, S.z * f)); resetHist(); zlabel(); refocusSoon(); }
function pan(dx, dy) {
  const vw = vid.videoWidth, vh = vid.videoHeight; if (!vw) return;
  const r = cropRect(); S.cx += dx * 0.12 * r.cw / vw; S.cy += dy * 0.12 * r.ch / vh; S.cx = Math.min(1, Math.max(0, S.cx)); S.cy = Math.min(1, Math.max(0, S.cy)); resetHist(); refocusSoon();
}
function makeBar(id, vertical, get, set) {          // thumb slider: drag the round thumb along the bar
  const el = $(id), th = el.querySelector(".th"); let drag = false, last = -1;
  const pos = e => { const r = el.getBoundingClientRect(); const p = vertical ? 1 - (e.clientY - r.top) / r.height : (e.clientX - r.left) / r.width; return Math.min(1, Math.max(0, p)); };
  el.addEventListener("pointerdown", e => { drag = true; try { el.setPointerCapture(e.pointerId); } catch (x) {} set(pos(e)); e.stopPropagation(); e.preventDefault(); });
  el.addEventListener("pointermove", e => { if (drag) { set(pos(e)); e.stopPropagation(); } });
  ["pointerup", "pointercancel"].forEach(ev => el.addEventListener(ev, e => { drag = false; e.stopPropagation(); }));
  return () => { const p = get(); if (Math.abs(p - last) < 0.002) return; last = p; th.style[vertical ? "bottom" : "left"] = "calc((100% - 28px) * " + p.toFixed(4) + ")"; };
}
const rangeX = () => { const vw = vid.videoWidth; if (!vw) return null; const lo = cropRect().cw / 2 / vw; return [lo, 1 - lo]; };
const rangeY = () => { const vh = vid.videoHeight; if (!vh) return null; const lo = cropRect().ch / 2 / vh; return [lo, 1 - lo]; };
const barUpdaters = [
  makeBar("barZ", true, () => Math.log10(S.z), p => { S.z = Math.pow(10, p); if (S.z < 1.03) S.z = 1; resetHist(); zlabel(); refocusSoon(); }),      // right bar: zoom (up = in)
  makeBar("barY", true, () => { const g = rangeY(); return g && g[1] > g[0] + 1e-6 ? 1 - (S.cy - g[0]) / (g[1] - g[0]) : .5; }, p => { const g = rangeY(); if (!g) return; S.cy = g[0] + (1 - p) * (g[1] - g[0]); resetHist(); refocusSoon(); }),   // left bar: up / down
  makeBar("barX", false, () => { const g = rangeX(); return g && g[1] > g[0] + 1e-6 ? (S.cx - g[0]) / (g[1] - g[0]) : .5; }, p => { const g = rangeX(); if (!g) return; S.cx = g[0] + p * (g[1] - g[0]); resetHist(); refocusSoon(); }),                  // bottom bar: left / right
];
function resetView() { S.z = 1; S.cx = S.cy = .5; resetHist(); zlabel(); refocusSoon(); }
/* two fingers = zoom, one finger = move, double tap = reset, single tap = focus there. Works only inside the camera box. */
(function () {
  const view = $("view"), ptr = new Map(); let lastDist = 0, lastTap = 0, tapId = 0, down = null, moved = 0;
  view.addEventListener("pointerdown", e => {
    if (e.target.closest("button, .bar") || S.mode !== "live") return;
    try { view.setPointerCapture(e.pointerId); } catch (x) {}
    ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastDist = 0; tapId++;
    if (ptr.size === 1) { down = { t: Date.now() }; moved = 0; const t = Date.now(); if (t - lastTap < 320) { resetView(); lastTap = 0; } else lastTap = t; }
    else down = null;
  });
  view.addEventListener("pointermove", e => {
    const p = ptr.get(e.pointerId); if (!p || S.mode !== "live" || !vid.videoWidth) return;
    const px = p.x, py = p.y; p.x = e.clientX; p.y = e.clientY; moved += Math.abs(p.x - px) + Math.abs(p.y - py);
    if (ptr.size >= 2) {
      const [a, b] = [...ptr.values()], d = Math.hypot(a.x - b.x, a.y - b.y);
      if (lastDist) zoom(d / lastDist); lastDist = d;
    } else if (moved > 10) {
      const r = view.getBoundingClientRect(), c = cropRect();
      S.cx += (px - p.x) / r.width * c.cw / vid.videoWidth; S.cy += (py - p.y) / r.height * c.ch / vid.videoHeight;
      S.cx = Math.min(1, Math.max(0, S.cx)); S.cy = Math.min(1, Math.max(0, S.cy)); resetHist();
    }
  });
  view.addEventListener("pointerup", e => {
    const wasOne = ptr.size === 1; ptr.delete(e.pointerId); lastDist = 0;
    if (!wasOne || S.mode !== "live") return;
    if (down && Date.now() - down.t < 300 && moved <= 10) {            // a tap: focus there (after the double-tap window)
      const id = tapId, x = e.clientX, y = e.clientY;
      setTimeout(() => { if (id === tapId && lastTap !== 0 && S.mode === "live") tapFocus(x, y); }, 340);
    } else if (moved > 10) refocusSoon();
  });
  view.addEventListener("pointercancel", e => { ptr.delete(e.pointerId); lastDist = 0; });
})();

/* ---------------- focus ---------------- */
let rfTimer = null;
async function focusAtVideo(nx, ny, force) {
  if (S.manualFocus && !force) return false;
  const tr = stream && stream.getVideoTracks()[0]; if (!tr) return false;
  let caps = {}; try { caps = tr.getCapabilities ? tr.getCapabilities() : {}; } catch (e) {}
  const modes = caps.focusMode || []; if (!modes.length) return false;
  const poi = { x: Math.min(1, Math.max(0, nx)), y: Math.min(1, Math.max(0, ny)) };
  try {
    if (modes.includes("single-shot")) {
      await tr.applyConstraints({ advanced: [{ focusMode: "single-shot", pointsOfInterest: [poi] }] });
      if (modes.includes("continuous")) setTimeout(() => { try { if (stream && tr.readyState === "live") tr.applyConstraints({ advanced: [{ focusMode: "continuous", pointsOfInterest: [poi] }] }).catch(() => {}); } catch (e) {} }, 1500);
    } else if (modes.includes("continuous")) await tr.applyConstraints({ advanced: [{ focusMode: "continuous", pointsOfInterest: [poi] }] });
    return true;
  } catch (e) { return false; }
}
function refocusSoon() {                                  // focus on the middle of the crop (where the card edge is) once the user stops moving
  clearTimeout(rfTimer);
  rfTimer = setTimeout(() => { if (S.mode === "live" && vid.videoWidth) focusAtVideo(S.cx, S.cy); }, 700);
}
const spc = document.createElement("canvas");
function stripSharpness() {                                // how sharp is the strip right now (edge energy on a small copy)
  const r = stripRect(), w = 480, h = Math.max(16, Math.round(w * r.ch / r.cw)); spc.width = w; spc.height = h;
  const c = spc.getContext("2d", { willReadFrequently: true }); c.drawImage(vid, r.sx, r.sy, r.cw, r.ch, 0, 0, w, h);
  const d = c.getImageData(0, 0, w, h).data, L = new Float32Array(w * h);
  for (let i = 0; i < L.length; i++) L[i] = d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
  let sum = 0; for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x, gx = L[i + 1] - L[i - 1], gy = L[i + w] - L[i - w]; sum += gx * gx + gy * gy; }
  return sum / (w * h);
}
async function sweepFocus() {                              // software autofocus: try focus distances, keep the one where the card edge is sharpest
  const tr = stream && stream.getVideoTracks()[0]; if (!tr || S.sweeping || S.mode !== "live" || !vid.videoWidth) return false;
  let caps = {}; try { caps = tr.getCapabilities ? tr.getCapabilities() : {}; } catch (e) {}
  const fd = caps.focusDistance, modes = caps.focusMode || [];
  if (!fd || fd.min == null || fd.max == null || !(fd.max > fd.min) || !modes.includes("manual")) return false;     // phone does not allow it: normal autofocus stays
  if (Date.now() - S.sweepT < 6000) return false; S.sweepT = Date.now(); S.sweeping = true;
  tag("Focusing..."); hint("Finding the sharpest focus on the card edge...");
  const set = async v => { await tr.applyConstraints({ advanced: [{ focusMode: "manual", focusDistance: v }] }); await sleep(250); const a = stripSharpness(); await sleep(70); return (a + stripSharpness()) / 2; };
  try {
    const base = stripSharpness(), n = 10, step = (fd.max - fd.min) / (n - 1); let best = { v: null, s: -1 };
    for (let i = 0; i < n && S.mode === "live"; i++) { const v = fd.min + step * i, sh = await set(v); if (sh > best.s) best = { v, s: sh }; }
    if (best.v != null && S.mode === "live") for (const d of [-.5, .5]) { const v = Math.min(fd.max, Math.max(fd.min, best.v + d * step)), sh = await set(v); if (sh > best.s) best = { v, s: sh }; }
    if (best.v != null && S.mode === "live" && best.s > base * 1.08) { await set(best.v); S.manualFocus = true; }     // clearly sharper than normal autofocus: lock it
    else { S.manualFocus = false; await tr.applyConstraints({ advanced: [{ focusMode: "continuous" }] }); }       // not better: back to normal autofocus
  } catch (e) { S.manualFocus = false; try { await tr.applyConstraints({ advanced: [{ focusMode: "continuous" }] }); } catch (x) {} }
  finally { S.sweeping = false; }
  return true;
}
function autoFocusCard(res, cw, ch, urgent, top) {              // keep the camera focused on the card edge itself (not the background)
  const vw = vid.videoWidth, vh = vid.videoHeight; if (!vw || !res.rows.length) return;
  const r = cropRect(), nx = (r.sx + ((res.xl + res.xr) / 2 / cw) * r.cw) / vw, ny = (r.sy + ((((top || 0) + (res.zy0 != null ? res.zy0 + res.zy1 : res.y0 + res.y1) / 2)) / (cw / S.aspect)) * r.ch) / vh;
  const now = Date.now(), moved = !S.afPt || Math.hypot(nx - S.afPt.x, ny - S.afPt.y) > 0.03;
  if ((moved && now - S.afT > 1200) || now - S.afT > (urgent ? 2500 : 6000)) { S.afT = now; S.afPt = { x: nx, y: ny }; focusAtVideo(nx, ny); }
}
const bgEls = ["bgT", "bgB", "bgL", "bgR", "zone"].map(id => $(id)); let maskSig = "";
function updateMask() {                                    // blur + dim everything except the reading strip (only place that is read)
  const on = S.mode === "live" || S.mode === "capturing" || (S.mode === "stopped" && S.last && S.last.top != null), f = stripFrac(), sig = on ? f.y0.toFixed(3) + "|" + f.h.toFixed(3) : "off";
  if (sig === maskSig) return; maskSig = sig;
  if (!on) { bgEls.forEach(e => e.classList.add("hide")); return; }
  const set = (e, bb, d) => { e.style.left = "0"; e.style.width = "100%"; e.style.top = bb + "%"; e.style.height = d + "%"; e.classList.remove("hide"); };
  set(bgEls[0], 0, f.y0 * 100); set(bgEls[1], f.y1 * 100, 100 - f.y1 * 100); set(bgEls[4], f.y0 * 100, f.h * 100); bgEls[2].classList.add("hide"); bgEls[3].classList.add("hide");
}
function tapFocus(cx, cy) {
  const view = $("view"), rect = view.getBoundingClientRect(), r = cropRect(), vw = vid.videoWidth, vh = vid.videoHeight; if (!vw) return;
  const fx = (cx - rect.left) / rect.width, fy = (cy - rect.top) / rect.height, ring = $("fring");
  ring.style.left = (cx - rect.left) + "px"; ring.style.top = (cy - rect.top) + "px";
  ring.classList.remove("hide", "go"); void ring.offsetWidth; ring.classList.add("go"); setTimeout(() => ring.classList.add("hide"), 900);
  resetHist(); S.manualFocus = false;
  focusAtVideo((r.sx + fx * r.cw) / vw, (r.sy + fy * r.ch) / vh, true);
}

/* ---------------- camera ---------------- */
async function startCam() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { hint("Camera is not available in this app/browser.", true); return; }
  hideResult(); resetHist(); S.afPt = null; S.afT = 0; S.reads = 0; S.lastTry = 0; S.failSig = null; S.noticeUntil = 0;        // a new start always clears the old result
  try { vctx.clearRect(0, 0, vcv.width, vcv.height); } catch (e) {}
  syncBtns(); tag(""); hint("Opening camera...");
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 3840 }, height: { ideal: 2160 }, frameRate: { ideal: 30 } }, audio: false });
  } catch (e) {
    const denied = /NotAllowed|Permission/i.test(e.name + e.message);
    hint(denied ? "Camera permission is off. Allow Camera for this app (Android Settings > Apps > Card Reader > Permissions), then press START again."
      : "Camera could not start (" + (e.name || e.message) + ").", true);
    return;
  }
  vid.srcObject = stream; try { await vid.play(); } catch (e) {}
  for (let i = 0; i < 50 && !vid.videoWidth; i++) await sleep(60);
  try {                                              // best picture the camera can give, shaped LANDSCAPE (the card edge is wide), + continuous focus
    const tr = stream.getVideoTracks()[0], caps = tr.getCapabilities ? tr.getCapabilities() : {};
    const long = Math.min(Math.max((caps.width && caps.width.max) || 0, (caps.height && caps.height.max) || 0, 1920), 3840), short = Math.round(long * 9 / 16);
    const portraitFrame = vid.videoHeight > vid.videoWidth;
    await tr.applyConstraints(portraitFrame ? { width: { ideal: short }, height: { ideal: long } } : { width: { ideal: long }, height: { ideal: short } });
    if (caps.focusMode && caps.focusMode.includes("continuous")) await tr.applyConstraints({ advanced: [{ focusMode: "continuous" }] });
  } catch (e) {}
  await sleep(300);
  try { if (navigator.wakeLock) wake = await navigator.wakeLock.request("screen"); } catch (e) {}
  S.ic = null; S.photoOpts = {};
  try {
    const tr2 = stream.getVideoTracks()[0]; if (typeof ImageCapture !== "undefined") {
      S.ic = new ImageCapture(tr2);
      S.ic.getPhotoCapabilities().then(pc => { if (pc.imageWidth && pc.imageHeight && pc.imageWidth.max && pc.imageHeight.max) { const w = Math.min(pc.imageWidth.max, 3072); S.photoOpts = { imageWidth: w, imageHeight: Math.round(w * pc.imageHeight.max / pc.imageWidth.max) }; } }).catch(() => {});
    }
  } catch (e) {}
  S.res = vid.videoWidth + "×" + vid.videoHeight + (vid.videoWidth >= 1900 ? " HD" : "");
  S.runMode = cfgMode; S.mode = "live"; resetHist(); S.z = 1; S.cx = S.cy = .5; S.busy = false; S.wantCapture = false; S.miss = 0; zlabel();
  syncBtns(); liveUI(true);
  if (S.runMode === "shot") { pill("PREVIEW · " + S.res, "live"); tag("Press CAPTURE"); hint("Put the card edge in the box, wait a moment for focus (or tap the edge), then press CAPTURE."); }
  else { pill("LIVE · " + S.res, "live"); tag("Looking for the card edge..."); hint("Move the camera so the card edge lies inside the bright strip. It takes the photo by itself when sharp and steady."); }
  requestAnimationFrame(drawLoop); S.manualFocus = false; focusAtVideo(.5, .5, true); setTimeout(() => { if (S.mode === "live") sweepFocus(); }, 1500);
  if (S.runMode !== "shot") startLoop();
}
function stopCam(auto) {
  const wasLive = S.mode === "live" || S.mode === "capturing";
  S.mode = "stopped"; S.wantCapture = false; clearTimeout(rfTimer);
  if (stream) stream.getTracks().forEach(t => t.stop()); stream = null; vid.srcObject = null;
  try { if (wake) wake.release(); } catch (e) {} wake = null;
  syncBtns(); liveUI(false); updateMask();
  if (!wasLive) return;
  drawFrozen();
  if (S.last && S.last.res.rows.length) { pill(auto ? "DONE" : "STOPPED", auto ? "ok" : ""); tag(auto ? "Stable reading" : "Stopped", auto); hint(S.last.res.rows.length + " cards read. Not right? Press TAKE NEW PHOTO or LIVE AGAIN."); }
  else { pill("STOPPED"); tag(""); hint("Stopped. Press TAKE PHOTO to try again."); }
}
const qcv = document.createElement("canvas");
function sigDiff(a, b) { let d = 0; for (let i = 0; i < a.length; i++) d += Math.abs(a[i] - b[i]); return d / a.length; }
function frameQuality() {                                  // ~10 ms: sharpness, card-edge evidence and a tiny fingerprint (to know if the phone is still)
  const r = stripRect(), w = 1106, h = Math.max(24, Math.round(w * r.ch / r.cw)); qcv.width = w; qcv.height = h;
  const c = qcv.getContext("2d", { willReadFrequently: true }); c.drawImage(vid, r.sx, r.sy, r.cw, r.ch, 0, 0, w, h);
  const d = c.getImageData(0, 0, w, h).data, L = new Float32Array(w * h);
  for (let i = 0, j = 0; j < L.length; i += 4, j++) L[j] = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
  const xa = Math.floor(w * .2), xb = Math.floor(w * .8), e = new Float64Array(h); let sh = 0, n = 0;
  for (let y = 1; y < h - 1; y++) { let a = 0, m = 0; for (let x = xa; x < xb; x += 2) { const i = y * w + x, gy = L[i + w] - L[i - w], gx = L[i + 1] - L[i - 1]; a += Math.abs(gy); sh += gx * gx + gy * gy; n++; m++; } e[y] = a / m; }
  const win = 20; let run = 0, best = 0;                   // busiest 20-row window (the card edge) vs the quietest 20% of rows
  for (let y = 1; y < h - 1; y++) { run += e[y]; if (y > win) run -= e[y - win]; if (y >= win && run / win > best) best = run / win; }
  const sorted = Float64Array.from(e.subarray(1, h - 1)).sort(), quiet = sorted[Math.floor(sorted.length * 0.2)];
  const gw = 48, gh = 12, sig = new Float32Array(gw * gh), cnt = new Float32Array(gw * gh);
  for (let y = 0; y < h; y++) { const gy2 = Math.min(gh - 1, Math.floor(y * gh / h)); for (let x = 0; x < w; x += 4) { const gx2 = Math.min(gw - 1, Math.floor(x * gw / w)); sig[gy2 * gw + gx2] += L[y * w + x]; cnt[gy2 * gw + gx2]++; } }
  for (let i = 0; i < sig.length; i++) sig[i] /= (cnt[i] || 1);
  return { sharp: sh / n, edge: best, quiet, sig };
}
async function waitSteady(ms) {                            // manual shutter: wait (max ms) until the phone is still, so the photo is not blurred
  const t0 = Date.now(); let prev = null, ok = 0; tag("Hold steady...");
  while (Date.now() - t0 < ms) {
    let q; try { q = frameQuality(); } catch (e) { return; }
    if (prev && sigDiff(q.sig, prev) < 3.5) { if (++ok >= 2) return; } else ok = 0;
    prev = q.sig; await sleep(70);
  }
}
async function bestShotLoop(myId) {                        // watches the preview; the moment the card edge is sharp AND the phone is steady, it takes the photo by itself
  const t0 = Date.now(), hist = []; let prev = null, steady = 0, best = 0;
  while (S.mode === "live" && myId === S.loopId) {
    if (!vid.videoWidth || S.sweeping) { await sleep(100); continue; }
    let q; try { q = frameQuality(); } catch (e) { await sleep(200); continue; }
    const mv = prev ? sigDiff(q.sig, prev) : 99; prev = q.sig; steady = mv < 3.5 ? steady + 1 : 0;
    hist.push(q.sharp); if (hist.length > 3) hist.shift(); best = Math.max(best * 0.97, q.sharp);
    const settled = hist.length === 3 && Math.max(...hist) <= 1.15 * Math.min(...hist) + 1;              // autofocus stopped hunting
    const edgeOK = q.edge >= 4, sharpOK = q.sharp >= 0.8 * best;                     // blank wall = no edge energy; anything with real lines is tried (the reader decides)
    const now = Date.now(), dt = now - S.lastTry, changed = !S.failSig || sigDiff(q.sig, S.failSig) > 5;    // after a failed shot: try again only when the view changed
    const autoOn = $("autostop").classList.contains("on");
    const ready = autoOn && edgeOK && steady >= 3 && settled && sharpOK && now - t0 > 1800 && ((changed && dt > 1200) || dt > 8000);
    if (now > S.noticeUntil) {
      if (!edgeOK) { tag("Looking for the card edge..."); hint("Move the camera so the card edge lies inside the bright strip."); }
      else if (steady < 3) { tag("Hold steady..."); hint("Keep the phone still for a moment."); }
      else if (!settled || !sharpOK) { tag("Focusing..."); hint("Waiting for a sharp picture..."); }
      else if (!autoOn) { tag("Ready"); hint("Press the camera button to read."); }
      else { tag("Best shot!"); hint("Taking the photo..."); }
    }
    if (ready) { S.lastTry = now; S.failSig = q.sig; capture(true); break; }
    await sleep(70);
  }
}
function startLoop() { const id = ++S.loopId; S.loopRun = bestShotLoop(id); }
const withTimeout = (p, ms) => { let t; return Promise.race([Promise.resolve(p), new Promise((_, rej) => { t = setTimeout(() => rej(new Error("timeout")), ms); })]).finally(() => clearTimeout(t)); };
async function grabStill() {                              // a real photo from the camera (sharper than a video frame), size capped so the phone does not choke
  const ic = S.ic; if (!ic) return null;
  try {
    const tries = []; if (S.photoOpts && S.photoOpts.imageWidth) tries.push(S.photoOpts); tries.push({});
    let blob = null;
    for (const o of tries) { try { blob = await withTimeout(ic.takePhoto(o), 3000); if (blob) break; } catch (e) {} }
    if (!blob || blob.size > 22e6) return null;
    const bmp = await withTimeout(createImageBitmap(blob), 5000);
    return { bmp, w: bmp.width, h: bmp.height };
  } catch (e) { return null; }
}
function paintStill(cv, st) {                             // same crop (zoom / position) as the live box, cut from the HD photo
  const vw = vid.videoWidth, vh = vid.videoHeight; if (!vw || !vh) return false;
  if ((st.w > st.h) !== (vw > vh)) return false;
  const r = stripRect(), k = st.w / vw, cw = r.cw * k, ch = r.ch * k;
  if (cw > st.w + 1 || ch > st.h + 1) return false;
  const cxp = (r.sx + r.cw / 2) * k, cyp = (r.sy + r.ch / 2 - vh / 2) * k + st.h / 2;
  const sx = Math.max(0, Math.min(cxp - cw / 2, st.w - cw)), sy = Math.max(0, Math.min(cyp - ch / 2, st.h - ch));
  const w = READ_W, h = Math.round(w * r.ch / r.cw); cv.width = w; cv.height = h;
  cv.getContext("2d", { willReadFrequently: true }).drawImage(st.bmp, sx, sy, Math.min(cw, st.w), Math.min(ch, st.h), 0, 0, w, h);
  return true;
}
async function hdStage() {
  const top0 = stripTopPx(), st = await grabStill(); if (!st) return null;
  try {
    const hcv = document.createElement("canvas");
    if (paintStill(hcv, st)) {                                                    // same strip as on screen, cut from the HD photo
      const res = await readAsync(hcv, camOpts({ fast: true }), 2, 12000).catch(() => null);
      return res && res.rows.length ? { canvas: hcv, res, src: "HD photo", top: top0 } : null;
    }
    const fcv = document.createElement("canvas"), w = READ_W, h = Math.min(3200, Math.round(st.h * w / st.w));   // crop not possible: whole photo (like "Read a photo")
    fcv.width = w; fcv.height = h; fcv.getContext("2d", { willReadFrequently: true }).drawImage(st.bmp, 0, 0, w, h);
    const res = await readAsync(fcv, { fast: true }, 2, 12000).catch(() => null);
    return res && res.rows.length ? { canvas: fcv, res, src: "HD photo" } : null;
  } finally { try { st.bmp.close && st.bmp.close(); } catch (e) {} }
}
function grabStripFrame() { const r0 = stripRect(), w = READ_W, h = Math.round(w * r0.ch / r0.cw), cv = document.createElement("canvas"); cv.width = w; cv.height = h; paintStrip(cv.getContext("2d", { willReadFrequently: true }), w, h); return { canvas: cv, top: stripTopPx() }; }
async function readStrip(fr, wi) {                         // never throws: gives {res} or {err}
  const ex = { fast: true }; if (S.hint && Date.now() - S.hint.t < 1500) ex.hint = S.hint;
  try {
    const res = await readAsync(fr.canvas, camOpts(ex), wi, 12000);
    return res.rows.length ? { canvas: fr.canvas, top: fr.top, res, src: "camera frame" } : { canvas: fr.canvas, top: fr.top, err: "No dots found." };
  } catch (e) { return { canvas: fr.canvas, top: fr.top, err: e.message || "Reading failed." }; }
}
function sameReads(a, b) { const x = a.res.rows, y = b.res.rows; if (x.length !== y.length) return false; let d = 0; for (let i = 0; i < x.length; i++) if (x[i].k !== y[i].k) d++; return d <= Math.max(1, Math.floor(x.length * 0.04)); }
function decide(reads, hdRead) {                           // 2 of 3 reads that agree win (card by card majority); otherwise trust the HD photo
  if (!reads.length) return null;
  let group = null;
  for (let i = 0; i < reads.length && !group; i++) { const g = reads.filter(r => sameReads(r, reads[i])); if (g.length >= 2) group = g; }
  const members = group || [hdRead && reads.includes(hdRead) ? hdRead : reads[0]], base = members.includes(hdRead) ? hdRead : members[0];
  if (members.length > 1) base.res.rows.forEach((t, i) => { const c = {}; members.forEach(m => { const k = m.res.rows[i].k; c[k] = (c[k] || 0) + (m === hdRead ? 1.1 : 1); }); t.k = +Object.keys(c).sort((a, b) => c[b] - c[a])[0]; });
  return { canvas: base.canvas, res: base.res, top: base.top, src: (base === hdRead ? "HD photo" : "camera frame") + (group ? " (verified)" : "") };
}
function finishCapture(id, fin, errs) {                    // the ONLY way a capture ends. It always ends STOPPED with the picture on screen + START AGAIN (never back to live)
  if (id !== S.capId || S.mode !== "capturing") return;
  S.capId++;
  if (!fin && S.last && S.last.res && S.last.res.rows.length) fin = { canvas: S.last.canvas, res: S.last.res, top: S.last.top, src: "quick read" };
  if (fin) {
    S.last = { canvas: fin.canvas, res: fin.res, top: fin.top }; try { showResult(fin.res, fin.canvas, true); } catch (e) { console.error(e); }
    try { navigator.vibrate && navigator.vibrate(160); } catch (e) {}
    stopCam(true);
    const n = fin.res.rows.length; pill("DONE", "ok"); tag(fin.src + ": " + n + " cards", true); hint(n + " cards read (" + fin.src + "). Press TAKE NEW PHOTO to read again.");
    return;
  }
  if (S.capAuto && S.runMode !== "shot") {
    const cut2 = (errs || []).some(e => /cut off/i.test(e || ""));
    S.mode = "live"; S.snap = null; syncBtns(); resetHist(); S.noticeUntil = Date.now() + 2500;
    tag(cut2 ? "Zoom out" : "Card not detected"); hint(cut2 ? CUTOFF : "That shot had no readable card edge. Adjust the camera and hold steady, trying again...", true);
    requestAnimationFrame(drawLoop); startLoop(); return;
  }
  const snap = S.snap, cutOff = (errs || []).some(e => /cut off/i.test(e || ""));
  S.last = snap ? { canvas: snap.canvas, top: snap.top, res: { rows: [], outside: [], xl: 0, xr: 0, y0: 0, y1: 0 } } : null;
  stopCam(false); pill("STOPPED"); tag(cutOff ? "Zoom out" : "Card not detected"); hint((cutOff ? CUTOFF : NOCARD) + " Press TAKE NEW PHOTO or LIVE AGAIN.", true);
}
async function runCapture(id) {
  const hd = $("hdshot").classList.contains("on"), frA = grabStripFrame(); S.snap = frA;       // the picture you took stays on screen whatever happens
  const pH = hd ? withTimeout(hdStage(), 8000).catch(() => null) : Promise.resolve(null);        // HD photo starts now, in parallel
  const a = await readStrip(frA, 1); if (id !== S.capId) return;                                 // instant read of this frame
  if (a.res) { S.last = { canvas: a.canvas, res: a.res, top: a.top }; try { showResult(a.res, a.canvas, true); } catch (e) { console.error(e); } drawFrozen(); if (hd) { tag("Result ready, checking HD photo..."); hint(a.res.rows.length + " cards. Making it more exact with the HD photo..."); } }
  const h = hd ? await Promise.race([pH, sleep(a.res ? 4500 : 8000).then(() => null)]) : null; if (id !== S.capId) return;
  const reads = [a, h].filter(x => x && x.res);
  finishCapture(id, decide(reads, h && h.res ? h : null), [a].filter(x => x && x.err).map(x => x.err));
}
async function capture(auto) {
  if (S.mode !== "live") return;
  const id = ++S.capId; S.loopId++; S.capAuto = !!auto;
  S.mode = "capturing"; S.wantCapture = false; syncBtns(); tag(auto ? "Best shot! Reading..." : "Reading..."); hint("Reading the photo...");
  if (!auto) { await waitSteady(700); if (id !== S.capId) return; tag("Reading..."); }
  killWorker(0);                                                                           // cut off any old read: all CPU goes to this photo
  const dog = setTimeout(() => finishCapture(id, null, []), 15000);                        // safety net: it can never hang longer than this
  try { await runCapture(id); } catch (e) { finishCapture(id, null, [e.message]); } finally { clearTimeout(dog); }
}
$("go").addEventListener("click", () => { if (S.mode === "capturing") { S.capId++; killWorker(1); killWorker(2); stopCam(false); return; } if (S.mode === "live") { S.runMode === "shot" ? capture(false) : stopCam(false); } else startCam(); });
$("shutter").addEventListener("click", () => capture(false));
$("stopbtn").addEventListener("click", () => stopCam(false));
$("rst").addEventListener("click", () => { if (S.mode === "live" || S.mode === "capturing") return; clearResult(); startCam(); });

/* ---------------- photo from gallery ---------------- */
/* ---------------- photos: from the phone camera app (most accurate) or from the gallery ---------------- */
async function readPhotoFile(f) {
  if (!f) return;
  if (S.mode === "live" || S.mode === "capturing") { S.capId++; stopCam(false); }
  hideResult(); S.mode = "stopped"; syncBtns(); pill("READING", ""); tag("Reading photo..."); hint("Reading photo...");
  const t0 = Date.now();
  try {
    const url = URL.createObjectURL(f), img = new Image();
    await new Promise((ok, bad) => { img.onload = ok; img.onerror = () => bad(new Error("This photo could not be opened.")); img.src = url; });
    URL.revokeObjectURL(url);
    const cv = canv[S.cur], w = READ_W, h = Math.min(3200, Math.round(img.naturalHeight * w / img.naturalWidth));
    cv.width = w; cv.height = h; cv.getContext("2d", { willReadFrequently: true }).drawImage(img, 0, 0, w, h);
    const res = await readAsync(cv, { fast: true, edgeOnly: $("strict").classList.contains("on") });     // same reader as before, quick slope search, ignores dots above / below the card edge
    S.last = { canvas: cv, res }; S.cur ^= 1; S.mode = "stopped";
    showResult(res, cv, true); drawFrozen(); syncBtns();
    const sec = ((Date.now() - t0) / 1000).toFixed(1), n = res.rows.length;
    pill(n ? "DONE" : "STOPPED", n ? "ok" : ""); tag(n ? "Photo: " + n + " cards (" + sec + " s)" : "Card not detected", !!n);
    hint(n ? n + " cards read from the photo in " + sec + " s." : "Card not detected in this photo.", !n);
  } catch (err) { S.mode = "stopped"; syncBtns(); pill("STOPPED", ""); tag("Card not detected"); hint(err.message || String(err), true); }
}
$("pick").addEventListener("click", () => $("file").click());
$("takephoto").addEventListener("click", () => $("camfile").click());                       // opens the phone's own camera app
["file", "camfile"].forEach(id => $(id).addEventListener("change", e => { const f = e.target.files && e.target.files[0]; e.target.value = ""; readPhotoFile(f); }));

/* ---------------- frozen frame with markers ---------------- */
function markers(ctx, res, sc, dy, ly0, ly1) {
  if (!res.rows.length) return;
  ctx.lineWidth = Math.max(2, 3 * sc); ctx.textAlign = "center"; ctx.font = `bold ${Math.round(34 * sc)}px ui-monospace, monospace`;
  res.rows.forEach((t, i) => {
    const odd = (i + 1) % 2, col = odd ? "#ff8a3d" : "#2dd4bf"; ctx.strokeStyle = col; ctx.fillStyle = col;
    ctx.beginPath(); ctx.arc(t.x * sc, (t.y - dy) * sc, 15 * sc, 0, 7); ctx.stroke(); ctx.fillText(String(t.k), t.x * sc, (t.y - dy) * sc + 54 * sc);
  });
  ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = Math.max(2, 3 * sc);
  [res.xl, res.xr].forEach(x => { ctx.beginPath(); ctx.moveTo(x * sc, ly0 || 0); ctx.lineTo(x * sc, ly1 || 4000 * sc); ctx.stroke(); });
}
function drawFrozen() {
  if (!S.last) return;
  const cv = S.last.canvas, w = 1280, top = S.last.top;
  if (top != null) {                                       // a strip reading: show it in its place inside the (last live) box
    const hv = Math.round(w / S.aspect), sc = w / cv.width;
    if (vcv.width !== w || vcv.height !== hv) { vcv.width = w; vcv.height = hv; }
    ovc.width = w; ovc.height = hv; vctx.drawImage(cv, 0, top * sc, w, cv.height * sc);
    markers(octx, S.last.res, sc, -top, top * sc, (top + cv.height) * sc);
  } else {                                                 // a whole photo
    const hv = Math.round(w * cv.height / cv.width); vcv.width = w; vcv.height = hv; ovc.width = w; ovc.height = hv;
    vctx.drawImage(cv, 0, 0, w, hv); markers(octx, S.last.res, w / cv.width, 0);
  }
  $("idle").classList.add("hide");
}

/* ---------------- result screen ---------------- */
let sel = 0;
const qrow = $("qrow");
for (let k = 1; k <= 13; k++) { const b = document.createElement("button"); b.className = "qb"; b.textContent = k; b.dataset.k = k; qrow.appendChild(b); }
qrow.addEventListener("click", e => { const b = e.target.closest(".qb"); if (!b) return; sel = sel === +b.dataset.k ? 0 : +b.dataset.k; find(); });

function showResult(res, cv, force) {
  const rows = res.rows, nums = rows.map(t => t.k), n = rows.length;
  const sig = nums.join(",") + "|" + (res.outside ? res.outside.length : 0) + "|" + Math.round(res.xl) + "|" + Math.round(res.xr);
  if (!force && sig === S.sig) return; S.sig = sig;
  $("emptyP").classList.toggle("hide", n > 0 || !!S.last); $("resBox").classList.toggle("hide", !S.last);
  const oddN = Math.ceil(n / 2), evenN = Math.floor(n / 2);
  $("tot").textContent = n; $("nodd").textContent = oddN; $("neven").textContent = evenN;
  const cnt = {}; nums.forEach(k => cnt[k] = (cnt[k] || 0) + 1);
  $("counts").innerHTML = Array.from({ length: 13 }, (_, i) => i + 1).map(k => `<div class="cn ${cnt[k] ? "has" : "dim"}"><b class="mono">${cnt[k] || 0}</b><small>No. ${k}</small></div>`).join("");
  $("chips").innerHTML = n ? rows.map((t, i) => `<div class="chip ${(i + 1) % 2 ? "odd" : "even"}">${t.k}<small>card ${i + 1}</small></div>`).join("") : `<div class="hint" style="margin:0">No cards read.</div>`;
  const li = (t, i) => `<li><span>card ${i + 1}</span><b class="mono">${t.k}</b></li>`;
  $("oddl").innerHTML = rows.map((t, i) => (i + 1) % 2 ? li(t, i) : "").join("") || `<li><span>-</span></li>`;
  $("evenl").innerHTML = rows.map((t, i) => (i + 1) % 2 ? "" : li(t, i)).join("") || `<li><span>-</span></li>`;
  $("tbl").querySelector("tbody").innerHTML = rows.map((t, i) => `<tr data-card="${i + 1}"><td class="mono">${i + 1}</td><td class="num"><b class="mono">${t.k}</b></td><td class="mono">${t.mm.toFixed(1)} mm</td><td><span class="tg ${(i + 1) % 2 ? "odd" : "even"}">${(i + 1) % 2 ? "ODD" : "EVEN"}</span></td></tr>`).join("");
  const notes = [];
  if (res.outside && res.outside.length) notes.push(`${res.outside.length} dot(s) were outside the card range and ignored.`);
  $("notes").innerHTML = notes.map(t => `<div class="note">${t}</div>`).join("");
  // detected-dots picture
  if (cv) {
    const pad = 70, y0 = Math.max(0, res.y0 - pad), y1 = Math.min(cv.height, res.y1 + 90), sh = $("shot");
    sh.width = cv.width; sh.height = y1 - y0; const c = sh.getContext("2d"); c.drawImage(cv, 0, y0, cv.width, y1 - y0, 0, 0, cv.width, y1 - y0);
    markers(c, res, 1, y0);
    const pl = res.xl / cv.width * 100, pr = res.xr / cv.width * 100;
    $("rl").value = pl; $("rr").value = pr; $("rlv").textContent = pl.toFixed(1) + "%"; $("rrv").textContent = pr.toFixed(1) + "%";
  }
  find();
}
function find() {
  document.querySelectorAll(".qb").forEach(b => b.classList.toggle("on", +b.dataset.k === sel));
  document.querySelectorAll("#tbl tr.hl").forEach(r => r.classList.remove("hl"));
  const box = $("qres"); if (!sel) { box.innerHTML = `<div class="hint" style="margin:0">Tap a number to see where it is.</div>`; return; }
  const rows = S.last ? S.last.res.rows : [], hits = [];
  rows.forEach((t, i) => { if (t.k === sel) hits.push([i + 1, t]); });
  if (!hits.length) { box.innerHTML = `<div class="qi">Number <b>${sel}</b> was not found in this stack.</div>`; return; }
  box.innerHTML = hits.map(([p, t], j) => `<div class="qi"><b class="nn">${j + 1}</b><span>Card <b>${p}</b> (from the top)</span><span class="sp"></span><span class="tg ${p % 2 ? "odd" : "even"}">${p % 2 ? "ODD" : "EVEN"} SIDE</span></div>`).join("") +
    `<div class="hint" style="margin:2px 2px 0">Number ${sel} found in ${hits.length} place${hits.length > 1 ? "s" : ""}.</div>`;
  hits.forEach(([p]) => { const r = document.querySelector(`#tbl tr[data-card="${p}"]`); if (r) r.classList.add("hl"); });
}

/* ---------------- fix card ends ---------------- */
$("rl").addEventListener("input", () => $("rlv").textContent = (+$("rl").value).toFixed(1) + "%");
$("rr").addEventListener("input", () => $("rrv").textContent = (+$("rr").value).toFixed(1) + "%");
async function reread(manual) {
  if (!S.last) return; const cv = S.last.canvas; hint("Reading again...");
  try { const res = await readAsync(cv, manual); S.last = { canvas: cv, res }; showResult(res, cv, true); if (S.mode !== "live") { drawFrozen(); } hint(res.rows.length + " cards read."); }
  catch (e) { hint(e.message, true); }
}
$("reread").addEventListener("click", () => { if (!S.last) return; const W = S.last.canvas.width; reread({ left: Math.round(+$("rl").value / 100 * W), right: Math.round(+$("rr").value / 100 * W) }); });
$("autoends").addEventListener("click", () => reread({}));

/* ---------------- copy ---------------- */
$("copy").addEventListener("click", async () => {
  if (!S.last) return; const nums = S.last.res.rows.map(t => t.k);
  const txt = `Total cards: ${nums.length}\nOrder (top to bottom): ${nums.join(" ")}\nODD side: ${nums.filter((_, i) => i % 2 === 0).join(" ")}\nEVEN side: ${nums.filter((_, i) => i % 2).join(" ")}`;
  try { await navigator.clipboard.writeText(txt); } catch (e) { const t = document.createElement("textarea"); t.value = txt; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); } catch (e2) {} t.remove(); }
  $("copytxt").textContent = "Copied"; setTimeout(() => $("copytxt").textContent = "Copy result", 1400);
});

window.__app = { S, readAsync, startCam, stopCam, sha256 };
