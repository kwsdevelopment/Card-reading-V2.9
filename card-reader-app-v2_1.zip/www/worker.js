importScripts("engine.js");
self.onmessage = e => {
  const m = e.data;
  try {
    const d = new Uint8ClampedArray(m.buf), n = m.W * m.H, g = new Float32Array(n);
    for (let i = 0, j = 0; i < n; i++, j += 4) g[i] = (4899 * d[j] + 9617 * d[j + 1] + 1868 * d[j + 2] + 8192) >> 14;
    const res = readBands(g, m.W, m.H, m.length, m.band, m.manual);
    self.postMessage({ id: m.id, res });
  } catch (err) { self.postMessage({ id: m.id, error: String(err && err.message || err) }); }
};
