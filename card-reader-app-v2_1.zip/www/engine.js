"use strict";
/* ---------- helpers ---------- */
const W0 = 2212;                                   // every photo is scaled to this width (all pixel limits were tuned for it)
const pyRound = v => { const f = Math.floor(v), d = v - f; return d < .5 ? f : d > .5 ? f + 1 : (f % 2 === 0 ? f : f + 1); };
const refl = (i, n) => { if (n === 1) return 0; while (i < 0 || i >= n) { if (i < 0) i = -i - 1; if (i >= n) i = 2 * n - i - 1; } return i; };
const refl101 = (i, n) => { if (n === 1) return 0; while (i < 0 || i >= n) { if (i < 0) i = -i; if (i >= n) i = 2 * n - 2 - i; } return i; };

function gaussKernel(sigma) {
  const r = Math.floor(4 * sigma + 0.5), k = new Float64Array(2 * r + 1); let s = 0;
  for (let i = -r; i <= r; i++) { k[i + r] = Math.exp(-0.5 * i * i / (sigma * sigma)); s += k[i + r]; }
  for (let i = 0; i < k.length; i++) k[i] /= s;
  return { k, r };
}
/* blur rows [r0,r1) of src (W wide) as if that strip were its own image; vertical pass first, like scipy. */
function gaussRows(src, W, r0, r1, sigma) { return gaussWin(src, W, r0, r1, sigma, 0, W); }
/* Same, but only for columns c0..c1-1 (result width c1-c0): far less work when only a part of the width is needed.
   Symmetric kernel: taps are added in pairs; both passes run as simple stride-1 loops (fast in JS). */
function gaussWin(src, W, r0, r1, sigma, c0, c1) {
  const h = r1 - r0, { k, r } = gaussKernel(sigma), k0 = k[r], kk = k.subarray(r + 1), cw = c1 - c0;
  const v0 = Math.max(0, c0 - r), v1 = Math.min(W, c1 + r), vw = v1 - v0;
  const tmp = new Float32Array(h * vw), out = new Float32Array(h * cw), acc = new Float64Array(vw), acc2 = new Float64Array(cw);
  for (let y = 0; y < h; y++) {                                                    // vertical pass
    const base = (r0 + y) * W + v0;
    for (let x = 0; x < vw; x++) acc[x] = k0 * src[base + x];
    for (let j = 1; j <= r; j++) {
      const w = kk[j - 1], pa = (r0 + refl(y - j, h)) * W + v0, pb = (r0 + refl(y + j, h)) * W + v0;
      for (let x = 0; x < vw; x++) acc[x] += w * (src[pa + x] + src[pb + x]);
    }
    const o = y * vw; for (let x = 0; x < vw; x++) tmp[o + x] = acc[x];
  }
  const xi0 = Math.max(c0, v0 + r), xi1 = Math.min(c1, v1 - r);                    // columns whose whole kernel lies inside the buffer
  for (let y = 0; y < h; y++) {                                                    // horizontal pass
    const o = y * vw, oo = y * cw;
    for (let x = 0; x < cw; x++) acc2[x] = 0;
    if (xi1 > xi0) {
      const b0 = o + xi0 - v0, n = xi1 - xi0, a0 = xi0 - c0;
      for (let x = 0; x < n; x++) acc2[a0 + x] = k0 * tmp[b0 + x];
      for (let j = 1; j <= r; j++) { const w = kk[j - 1]; for (let x = 0; x < n; x++) acc2[a0 + x] += w * (tmp[b0 + x - j] + tmp[b0 + x + j]); }
    }
    for (let x = c0; x < c1; x++) {
      if (xi1 > xi0 && x === xi0) { x = xi1 - 1; continue; }                       // skip the interior (done above)
      let a = k0 * tmp[o + x - v0];
      for (let j = 1; j <= r; j++) a += kk[j - 1] * (tmp[o + refl(x - j, W) - v0] + tmp[o + refl(x + j, W) - v0]);
      acc2[x - c0] = a;
    }
    for (let x = 0; x < cw; x++) out[oo + x] = acc2[x];
  }
  return out;
}
function percentile(arr, p) {
  const a = Float64Array.from(arr).sort(), n = a.length, idx = p / 100 * (n - 1), lo = Math.floor(idx), fr = idx - lo;
  return lo + 1 < n ? a[lo] * (1 - fr) + a[lo + 1] * fr : a[lo];
}

/* ---------- 1. where is the stack ---------- */
function findStacks(g, W, H) {            // candidate stacks (strongest horizontal edge bands), best-looking first. Returns { centers, stackAt(yc) } (stackAt is lazy)
  const xa = Math.floor(W * .3), xb = Math.floor(W * .7), ya = Math.floor(H * .08), yb = Math.floor(H * .92);
  const sob = (G, gw, ra, rb, x) => Math.abs((G[rb + x - 1] + 2 * G[rb + x] + G[rb + x + 1]) - (G[ra + x - 1] + 2 * G[ra + x] + G[ra + x + 1]));
  // profile: |Sobel dy| smoothed over +-100 px, averaged over the middle 40% of the width -> only columns xa-101 .. xb+101 are needed
  const c0 = Math.max(1, xa - 101), c1 = Math.min(W - 1, xb + 102), R0 = Math.max(0, ya - 1 - 6), R1 = Math.min(H, yb + 1 + 7);
  const Gp = gaussWin(g, W, R0, R1, 1.2, c0 - 1, c1 + 1), gw = c1 - c0 + 2, prof = new Float64Array(H), S = new Float64Array(gw + 2);
  for (let y = ya; y < yb; y++) {
    const ra = (y - 1 - R0) * gw, rb = (y + 1 - R0) * gw; S[0] = 0;
    for (let x = 0; x < gw - 2; x++) S[x + 1] = S[x] + sob(Gp, gw, ra, rb, x + 1);                  // S over columns c0 .. c1-1
    let m = 0;
    for (let x = xa; x < xb; x++) { const hi = Math.min(c1, x + 101), lo = Math.max(c0, x - 100); m += (S[hi - c0] - S[lo - c0]) / 201; }
    prof[y] = m / (xb - xa);
  }
  const argmax = (lo, hi, arr) => { let bv = -1, by = -1; for (let y = lo; y < hi; y++) if (arr[y] > bv) { bv = arr[y]; by = y; } return by; };
  const centers = [argmax(Math.floor(H * .2), Math.floor(H * .7), prof)];      // the classic choice first
  const p2 = Float64Array.from(prof), p2b = Float64Array.from(prof);
  for (let n = 0; n < 2; n++) {                                               // then the strongest bands elsewhere
    for (const c of centers) for (let y = Math.max(0, c - 150); y < Math.min(H, c + 150); y++) p2[y] = 0;
    const by = argmax(ya, yb, p2); if (by < 0 || p2[by] <= 0) break; centers.push(by);
  }
  const stackAt = yc => {
    const y0 = Math.max(0, yc - 140), y1 = Math.min(H, yc + 90);
    const r0 = Math.max(0, y0 - 1 - 6), r1 = Math.min(H, y1 + 1 + 7), G = gaussRows(g, W, r0, r1, 1.2);   // strip with margin = same rows as the whole-image blur
    const col = new Float64Array(W);
    for (let y = y0; y < y1; y++) {
      const ra = (refl101(y - 1, H) - r0) * W, rb = (refl101(y + 1, H) - r0) * W;
      for (let x = 0; x < W; x++) {
        const xl = x === 0 ? 1 : x - 1, xr = x === W - 1 ? W - 2 : x + 1;                                       // reflect-101 borders, like OpenCV
        col[x] += Math.abs((G[rb + xl] + 2 * G[rb + x] + G[rb + xr]) - (G[ra + xl] + 2 * G[ra + x] + G[ra + xr]));
      }
    }
    for (let x = 0; x < W; x++) col[x] /= (y1 - y0);
    const c2 = new Float64Array(W);
    for (let x = 0; x < W; x++) { let a = 0; for (let j = -7; j <= 7; j++) a += col[refl(x + j, W)]; c2[x] = a / 15; }
    const thr = 0.35 * percentile(c2, 90);
    const xs = []; for (let x = 0; x < W; x++) if (c2[x] > thr && x > 2 && x < W - 3) xs.push(x);
    if (!xs.length) return { y0, y1, xl: null, xr: null };
    const runs = [[xs[0]]];
    for (let i = 1; i < xs.length; i++) (xs[i] - xs[i - 1] > 40 ? runs.push([xs[i]]) : runs[runs.length - 1].push(xs[i]));
    let run = runs[0]; for (const r of runs) if (r.length > run.length) run = r;
    let xl = run[0], xr = run[run.length - 1];
    const clipL = xl <= 5, clipR = xr >= W - 6;                                // the card runs past the picture edge: its length is NOT fully visible
    if (xl <= 8) xl = 0; if (xr >= W - 9) xr = W - 1;                          // card reaches the frame edge
    return { y0, y1, xl, xr, clipL, clipR };
  };
  const cs = centers.filter(c => c >= 0);
  return { centers: cs, strength: cs.map(c => (c === centers[0] ? prof[c] : p2b[c])), stackAt };
}

/* ---------- 2. dot candidates ---------- */
function findDots(g, W, H, y0, y1, xl, xr, half) {
  const cx0 = Math.floor(xl) + 30, cx1 = Math.floor(xr) - 30, out = [];                         // dots are only searched between these columns
  if (cx1 <= cx0) return { dots: out };
  const R0 = Math.max(0, y0 - 24), R1 = Math.min(H, y1 + 24), rh = R1 - R0;
  const c0 = Math.max(0, cx0 - 41), c1 = Math.min(W, cx1 + 41), cw = c1 - c0;                   // columns that matter (+ the 81 px median window)
  const a = gaussWin(g, W, R0, R1, 1.5, c0, c1), b = gaussWin(g, W, R0, R1, 4.0, c0, c1);
  const r = new Float32Array(rh * cw);
  for (let i = 0; i < r.length; i++) r[i] = -(a[i] - b[i]);         // r: dark small blob = high
  // base: median along the row (81 px), floor at 0, then max over 3 rows
  const n = cx1 - cx0, win = new Float32Array(81), pad = new Float32Array(n + 80);
  const med = rowIdx => {
    const o = rowIdx * cw, res = new Float32Array(n);
    for (let i = 0; i < pad.length; i++) pad[i] = r[o + refl(cx0 - 40 + i, W) - c0];
    win.set(pad.subarray(0, 81)); win.sort();
    res[0] = win[40] > 0 ? win[40] : 0;
    for (let x = 1; x < n; x++) {
      const outv = pad[x - 1], inv = pad[x + 80];
      let lo = 0, hi = 80; while (lo < hi) { const m = (lo + hi) >> 1; win[m] < outv ? lo = m + 1 : hi = m; }
      win.copyWithin(lo, lo + 1, 81);                                // drop outv; 80 valid values remain
      let p = 0; hi = 80; while (p < hi) { const m = (p + hi) >> 1; win[m] <= inv ? p = m + 1 : hi = m; }
      win.copyWithin(p + 1, p, 80); win[p] = inv;                    // insert inv, sorted
      res[x] = win[40] > 0 ? win[40] : 0;
    }
    return res;
  };
  const medRows = new Map();
  for (let y = Math.max(0, y0 - 1); y <= Math.min(H - 1, y1); y++) medRows.set(y, med(y - R0));
  const nrow = y1 - y0, ex = new Float32Array(nrow * n);
  for (let y = y0; y < y1; y++) {
    const m0 = medRows.get(refl(y - 1, H)) || medRows.get(y), m1 = medRows.get(y), m2 = medRows.get(refl(y + 1, H)) || medRows.get(y), ro = (y - R0) * cw - c0, eo = (y - y0) * n - cx0;
    for (let x = cx0; x < cx1; x++) { const i = x - cx0; ex[eo + x] = r[ro + x] - Math.max(m0[i], m1[i], m2[i]); }
  }
  const val = (y, x) => (y < y0 || y >= y1 || x < cx0 || x >= cx1) ? 0 : ex[(y - y0) * n + x - cx0];
  for (let y = y0; y < y1; y++) for (let x = cx0; x < cx1; x++) {
    const v = ex[(y - y0) * n + x - cx0];
    if (!(v > 20) || !(g[y * W + x] < 140) || y < 10 || x < 14) continue;
    let ok = true;
    for (let dy = -half; dy <= half && ok; dy++) for (let dx = -half; dx <= half; dx++) if (val(y + dy, x + dx) > v) { ok = false; break; }
    if (ok) out.push([x, y, v]);
  }
  return { dots: out };
}

/* ---------- 3. tilt of the card layers ---------- */
function layerSlope(g, W, y0, y1, xl, xr, sHint, fast, out) {
  const x0 = xl + 20, x1 = xr - 20, w = x1 - x0, h = y1 - y0;
  const crop = new Float32Array(h * w);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) crop[y * w + x] = g[(y0 + y) * W + x0 + x];
  const sub = gaussRows(crop, w, 0, h, 1.0);
  const xa = Math.floor(w / 8), xb = Math.floor(7 * w / 8), p = new Float64Array(h), ox = new Int32Array(w + 1);
  const variance = (i, step) => {                              // how "layered" the picture looks when tilted by slope index i
    const s = -0.08 + i * 0.001;
    for (let x = xa; x < xb; x += step) ox[x] = Math.round(-s * x * 1024);                   // per-column offset (same value the old per-sample formula gave)
    const hm = h - 1;
    for (let y = 0; y < h; y++) {
      let a = 0, n = 0; const y1024 = y * 1024 + 16;
      for (let x = xa; x < xb; x += step) {
        const yf = (ox[x] + y1024) >> 5, iy = yf >> 5, fy = yf & 31;
        const i0 = iy < 0 ? 0 : iy > hm ? hm : iy, i1 = iy + 1 < 0 ? 0 : iy + 1 > hm ? hm : iy + 1;
        a += (sub[i0 * w + x] * (32 - fy) + sub[i1 * w + x] * fy) * 0.03125; n++;
      }
      p[y] = a / n;
    }
    let m = 0; for (let y = 0; y < h - 1; y++) m += p[y + 1] - p[y]; m /= (h - 1);
    let v = 0; for (let y = 0; y < h - 1; y++) { const d = p[y + 1] - p[y] - m; v += Math.min(d * d, 1600); } return v / (h - 1);   // a single big step (face / table boundary) counts as one ripple only
  };
  let best = -1, bi = 80;
  const scan = (from, to, stp, step) => { for (let i = from; i < to; i += stp) { const v = variance(i, step); if (v > best) { best = v; bi = i; } } };
  if (sHint != null) { const ic = Math.round((-sHint + 0.08) * 1000); scan(Math.max(0, ic - 4), Math.min(161, ic + 5), 1, 1); }   // tracking: only a few slopes near the last one
  else if (fast) { scan(0, 161, 4, 2); const c = bi; best = -1; scan(Math.max(0, c - 5), Math.min(161, c + 6), 1, 1); }          // quick read: coarse search then fine
  else scan(0, 161, 1, 1);                                                                                                       // exact: all 161 slopes
  if (out) { variance(bi, 1); out.p = Float64Array.from(p); out.h = h; out.x0 = x0; }        // profile of the best tilt: layered edge = strong ripples
  return -(-0.08 + bi * 0.001);
}

/* where does the LAYERED card edge sit (in the tilted "c" coordinate)? Printed top face, table and background are smooth when averaged along the layers,
   so only the real stack edge ripples. Returns [c0, c1] or null when the evidence is not clear (then nothing is cut). */
function stackExtent(p, h) {
  if (!p || h < 40) return null;
  const E = new Float64Array(h), K = 5;
  for (let y = 0; y < h; y++) { let a = 0, n = 0; for (let k = -K; k <= K; k++) { const j = y + k; if (j >= 0 && j < h - 1) { const d = p[j + 1] - p[j]; a += d * d; n++; } } E[y] = n ? Math.sqrt(a / n) : 0; }
  const sorted = Float64Array.from(E).sort(), ref = sorted[Math.floor(0.9 * (h - 1))], quiet = sorted[Math.floor(0.15 * (h - 1))];
  if (!(ref > 1.5) || ref < 3 * (quiet + 0.3)) return null;                       // no clear "ripple region vs smooth region" contrast: do not cut anything
  const thr = 0.3 * ref, runs = []; let cur = null;
  for (let y = 0; y < h; y++) if (E[y] >= thr) { if (cur && y - cur.b <= 9) { cur.b = y; cur.sum += E[y]; } else { cur = { a: y, b: y, sum: E[y] }; runs.push(cur); } }
  if (!runs.length) return null;
  let run = runs[0]; for (const r of runs) if (r.sum > run.sum) run = r;
  if (run.b - run.a < 24) return null;
  return [run.a, run.b];
}


/* ---------- sharpness of the card-edge band (used to skip blurry live frames) ---------- */
function sharpness(g, W, H, y0, y1, xl, xr) {
  const a = Math.max(2, Math.floor(xl) + 20), b = Math.min(W - 2, Math.floor(xr) - 20);
  const ya = Math.max(1, y0), yb = Math.min(H - 1, y1); let s = 0, n = 0;
  for (let y = ya; y < yb; y++) for (let x = a; x < b; x += 2) {
    const i = y * W + x, l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - W] - g[i + W]; s += l * l; n++;
  }
  return n ? s / n : 0;
}

/* ---------- 4. band reading: every B mm = one number (0-B = 1, B-2B = 2 ... 13B = 13) ---------- */
function cleanDots(rawDots) {
  let dots = rawDots.slice().sort((a, b) => b[2] - a[2]);
  const keep = [];
  for (const d of dots) if (d[2] >= 25 && keep.every(k => !(Math.abs(d[1] - k[1]) <= 3 && Math.abs(d[0] - k[0]) <= 12))) keep.push(d);
  dots = keep.sort((a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2]);
  const strong = dots.filter(d => d[2] >= 33);
  if (strong.length) {
    const lo = Math.min(...strong.map(d => d[1])), hi = Math.max(...strong.map(d => d[1]));
    dots = dots.filter(d => d[2] >= 33 || (lo - 14 <= d[1] && d[1] <= hi + 14));
  }
  return dots;
}
const SKIP_WEAK = +(typeof self !== "undefined" && self.SKIP_WEAK_OVERRIDE != null ? self.SKIP_WEAK_OVERRIDE : 0.5);
function readBands(g, W, H, lengthMM, B, manual) {
  manual = manual || {};
  const hint = manual.hint && manual.hint.xl != null && manual.hint.xr != null ? manual.hint : null;     // live tracking: card place known from the last read, skip the full search
  const fs = hint ? null : findStacks(g, W, H);
  const cands = hint ? [{ y0: hint.y0, y1: hint.y1, xl: hint.xl, xr: hint.xr, clipL: hint.clipL, clipR: hint.clipR }] : fs.centers; let best = null;
  for (let ci = 0; ci < cands.length; ci++) {
    const cand = cands[ci];
    if (!hint && ci > 0) {                                                                      // weaker edge bands than the first one: not worth a full dot search
      const rel = fs.strength[ci] / fs.strength[0];
      if (rel < SKIP_WEAK || (rel < 0.7 && best && best.dots.length >= 8)) continue;             // (a tall stack makes a 2nd strong band: those are always checked)
    }
    const st = hint ? cand : fs.stackAt(cand);
    const xl = manual.left != null ? manual.left : st.xl, xr = manual.right != null ? manual.right : st.xr;
    if (xl == null || xr == null || xr - xl < 300) continue;
    const fd = findDots(g, W, H, st.y0, st.y1, xl, xr, 2), dots = cleanDots(fd.dots);
    if (!best || dots.length > best.dots.length) best = { st, xl, xr, dots, fd };
  }
  if (!best) throw new Error("Card not detected.");
  if (manual.strict && manual.left == null && manual.right == null && best.xr - best.xl < 0.25 * W) throw new Error("Card not detected.");
  if (manual.strict && manual.left == null && manual.right == null && (best.st.clipL || best.st.clipR)) throw new Error("Card ends cut off.");   // card length not fully visible = wrong mm scale   // camera readings: a real card fills the box
  const { xl, xr } = best, y0 = best.st.y0, y1 = best.st.y1, autoL = best.st.xl, autoR = best.st.xr;
  let dots = best.dots;
  const ext = {}, s = layerSlope(g, W, y0, y1, Math.floor(xl), Math.floor(xr), hint ? hint.s : null, !!manual.fast, ext);
  const run = (manual.strict || manual.edgeOnly) && manual.left == null && manual.right == null ? stackExtent(ext.p, ext.h) : null;      // camera readings: ignore everything above / below the layered edge
  let offEdge = 0, useRun = run;
  if (run) { const keep = dots.filter(([x, y]) => { const cl = (y - y0) - s * (x - ext.x0); return cl >= run[0] - 6 && cl <= run[1] + 6; }).length; if (dots.length >= 6 && keep < 0.4 * dots.length) useRun = null; }   // filter would delete most dots: evidence not trustworthy
  const pxmm = (xr - xl) / lengthMM, maxMM = 13 * B;
  let rows = [], outside = [];
  for (const [x, y] of dots) {
    if (useRun) { const cl = (y - y0) - s * (x - ext.x0); if (cl < run[0] - 6 || cl > run[1] + 6) { offEdge++; continue; } }       // not on the card edge: ignored
    const mm = (x - xl) / pxmm;
    if (mm < 0 || mm > maxMM) { outside.push({ x, y, mm }); continue; }
    rows.push({ c: y - s * x, x, y, mm, k: Math.max(1, Math.ceil(mm / B)) });
  }
  // a dot sitting within 0.5 mm of a band edge joins the side that has more dots within 1.5 mm of it
  const mms = rows.map(t => t.mm);
  rows = rows.map((t, i) => {
    const q = t.mm / B, r0 = pyRound(q);
    if (Math.abs(q - r0) * B < 0.5 && r0 >= 1) {
      let lo = 0, hi = 0;
      mms.forEach((m, j) => { if (j === i) return; if (m >= t.mm - 1.5 && m < t.mm) lo++; if (m > t.mm && m <= t.mm + 1.5) hi++; });
      let k = t.k; if (lo !== hi) k = lo > hi ? r0 : r0 + 1;
      t = Object.assign({}, t, { k: Math.max(1, Math.min(13, k)) });
    }
    return t;
  });
  rows.sort((a, b) => a.c - b.c || a.x - b.x || a.y - b.y);
  if (manual.strict && manual.left == null && manual.right == null) {          // is this really a pen-dot card? (camera readings only)
    const nIn = rows.length, nOut = outside.length, tot = nIn + nOut, bandMM = (y1 - y0) / pxmm;
    let tiny = 0; if (nIn > 1) { const cs = rows.map(t => t.c).sort((a, b) => a - b); for (let i = 1; i < cs.length; i++) if (cs[i] - cs[i - 1] < 3) tiny++; tiny /= (cs.length - 1); }
    // real dots exist only in the 0-65 mm zone; background clutter spreads over the whole width. Also: far too many "cards" for the stack height.
    if ((nOut >= 4 && nOut / tot >= 0.2) || nIn > 12 * bandMM || (tot >= 15 && tiny >= 0.45 && nOut / tot >= 0.12)) throw new Error("Card not detected.");
  }
  let zy0 = y0, zy1 = y1;                                                       // the card-edge zone: only dots in here are counted
  if (rows.length) {
    const ys = rows.map(t => t.y); zy0 = Math.max(y0, Math.min(...ys) - 30); zy1 = Math.min(y1, Math.max(...ys) + 30);
    if (zy1 - zy0 < 90) { const m = (zy0 + zy1) / 2; zy0 = Math.max(y0, m - 45); zy1 = Math.min(y1, m + 45); }
  }
  return { offEdge, edgeRun: run, clipL: !!best.st.clipL, clipR: !!best.st.clipR, zy0, zy1, rows, outside, xl, xr, autoL, autoR, y0, y1, s, pxmm, W, H, seen: dots.length, cands: cands.length, sharp: sharpness(g, W, H, y0, y1, xl, xr) };
}
if (typeof self !== "undefined") self.readBands = readBands;
